import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UploadComponent } from '../upload/upload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import {TableModule} from 'primeng/table';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {ToastModule} from 'primeng/toast';
import {SliderModule} from 'primeng/slider';
import {InputNumberModule} from 'primeng/inputnumber';
const uploadRoutes: Routes = [{
  path: '',
  component: UploadComponent
}];

@NgModule({
  declarations: [UploadComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(uploadRoutes),
    FormsModule, 
    ReactiveFormsModule,
    MatTableModule,
    ToastModule,
    TableModule,
    ProgressSpinnerModule,
    InputTextareaModule,
    SliderModule,
    InputNumberModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class UploadModule { }
