import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import {StockProjectionService} from './services/stock-projection.service';
@Component({
  selector: 'app-stock-projection',
  templateUrl: './stock-projection.component.html',
  styleUrls: ['./stock-projection.component.scss']
})
export class StockProjectionComponent implements OnInit {

  constructor(private stockProjectionService:StockProjectionService) { }

  ngOnInit(): void {
    // this.stockProjectionService.getStockDetails().subscribe(resp => {
    //   console.log(resp)
    // })
  }

}
