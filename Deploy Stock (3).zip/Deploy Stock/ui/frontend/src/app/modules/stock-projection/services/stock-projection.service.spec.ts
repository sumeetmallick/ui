import { TestBed } from '@angular/core/testing';

import { StockProjectionService } from './stock-projection.service';

describe('StockProjectionService', () => {
  let service: StockProjectionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StockProjectionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
